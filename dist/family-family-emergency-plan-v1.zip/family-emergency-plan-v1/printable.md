# Family Emergency Plan + Go-Bag Checklist

This printable summary accompanies the digital files in this pack.

## What's inside
- go_bag_checklist.csv
- family_plan_template.csv
- printable.md
- LICENSE.txt

## How to use
1. Open CSV files in Excel/Google Sheets or import into Notion.
2. Import TSV into Anki (Basic note type).
3. Print this page to PDF if you want a hard copy.

## Sources & License
- FEMA-style checklist (sample).
- Maintain required notices. Compiled work © YourBrand.

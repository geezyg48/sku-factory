# Macro Planner: Foods & Macros (USDA sample)

This printable summary accompanies the digital files in this pack.

## What's inside
- foods.csv
- planner_template.csv
- anki.tsv
- printable.md
- LICENSE.txt

## How to use
1. Open CSV files in Excel/Google Sheets or import into Notion.
2. Import TSV into Anki (Basic note type).
3. Print this page to PDF if you want a hard copy.

## Sources & License
- USDA sample (public domain). Replace with live USDA pulls.
- Compiled work © YourBrand. Underlying data public domain.

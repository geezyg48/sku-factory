# Macro Planner

Fill `planner_template.csv` using `foods.csv` as reference.
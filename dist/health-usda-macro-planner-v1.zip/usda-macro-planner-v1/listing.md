# Macro Planner: Foods & Macros (USDA sample)

**What's inside**
- foods.csv
- planner_template.csv
- anki.tsv
- printable.md
- LICENSE.txt

**Why it helps**
- Structured, editable CSVs and TSV (Anki) for quick onboarding.
- Printable quickstart (markdown -> PDF).
- Built from public-domain/permissive sources with clear licensing notes.

**How to use**
1) Open CSVs in Sheets/Excel/Notion.
2) Import TSV into Anki.
3) Print the markdown if you need a hard copy.

**Sources & License**
- USDA sample (public domain). Replace with live USDA pulls.
- Compiled work © YourBrand. Underlying data public domain.

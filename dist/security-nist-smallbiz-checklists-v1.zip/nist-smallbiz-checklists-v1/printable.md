# NIST Small Business Security Checklist + Vendor Tracker

This printable summary accompanies the digital files in this pack.

## What's inside
- nist_checklist.csv
- vendor_risk_tracker.csv
- printable.md
- LICENSE.txt

## How to use
1. Open CSV files in Excel/Google Sheets or import into Notion.
2. Import TSV into Anki (Basic note type).
3. Print this page to PDF if you want a hard copy.

## Sources & License
- NIST-derived small business summary (sample).
- Maintain required notices. Compiled work © YourBrand.

# NIST Small Business Security Checklist + Vendor Tracker

**What's inside**
- nist_checklist.csv
- vendor_risk_tracker.csv
- printable.md
- LICENSE.txt

**Why it helps**
- Structured, editable CSVs and TSV (Anki) for quick onboarding.
- Printable quickstart (markdown -> PDF).
- Built from public-domain/permissive sources with clear licensing notes.

**How to use**
1) Open CSVs in Sheets/Excel/Notion.
2) Import TSV into Anki.
3) Print the markdown if you need a hard copy.

**Sources & License**
- NIST-derived small business summary (sample).
- Maintain required notices. Compiled work © YourBrand.
